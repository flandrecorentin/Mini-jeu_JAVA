*******************************************************************************
Cette archive "Mini-jeu_Java" concerne une plateforme de mini-jeux codés 
purement en JAVA. Pour pouvoir jouer il faut avoir de quoi compilater un 
programme java sur son PC, ainsi qu'un jdk (Java Development Kit) assez récent.
Afin de lancer la plateforme de jeu, il suffit d'executer le bon fichier 
selon votre système d'exploitation (JeuLinux.sh ou JeuWindows.bat). Les codes
sources et les assets sont tous disponibles dans le fichier JAVA_Code.
Si vous n'arrivez pas à ouvrir le Jeu ou que vous voulez des informations 
supplémentaires, contactez-moi (flandrecorentin@gmail.com).
Cette plateforme de jeu a été créé durant ma 1° année d'école d'ingénieur.  
*******************************************************************************