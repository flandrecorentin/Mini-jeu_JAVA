public class Jeu{
	public static void main(String[] args){
		 new SelectionJeu();
	}
}
